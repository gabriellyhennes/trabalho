module.exports = {
  jwtSecret: process.env.JWT_SECRET || '95b63041-d56c-4bc0-b3fd-65e45f3c16ac'
};