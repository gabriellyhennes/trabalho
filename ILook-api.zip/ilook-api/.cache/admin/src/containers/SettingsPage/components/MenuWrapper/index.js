import styled from 'styled-components';

// background-color: red;
const MenuWrapper = styled.div`
  background-color: ${props => props.theme.main.colors.mediumGrey};
`;

export default MenuWrapper;
