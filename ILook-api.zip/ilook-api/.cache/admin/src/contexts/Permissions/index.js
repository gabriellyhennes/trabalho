import { createContext } from 'react';

const PermissionsContext = createContext({});

export default PermissionsContext;
