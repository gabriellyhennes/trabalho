/* eslint-disable indent */
import styled from 'styled-components';

const Wrapper = styled.div`
  padding-left: 15px;
`;

export default Wrapper;
